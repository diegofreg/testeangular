import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { of, tap } from 'rxjs';
import { AuthService } from 'src/app/services/auth/auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const service = inject(AuthService);

  return of(service.isAuthenticated).pipe(
    tap((value) => {
      return !value ? router.navigate(['/login']) : true;
    })
  );
};
