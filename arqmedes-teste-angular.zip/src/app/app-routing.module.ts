import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { ContainerComponent } from './layout/container/container.component';
import { UsersPageComponent } from './pages/users-page/users-page.component';
import { UserPageComponent } from './pages/user-page/user-page.component';
import { authGuard } from './guards/auth/auth.guard';
import { nonAuthGuard } from './guards/non-auth/non-auth.guard';

const routes: Routes = [
  {
    path: 'dashboard',
    component: ContainerComponent,
    canActivate: [authGuard],
    children: [
      {
        path: 'users',
        component: UsersPageComponent,
      },
      {
        path: 'users/new',
        component: UserPageComponent,
      },
      {
        path: 'users/edit/:id',
        component: UserPageComponent,
      },

      {
        path: '**',
        redirectTo: '/dashboard/users',
      },
    ],
  },
  {
    canActivate: [nonAuthGuard],
    path: 'login',
    component: LoginComponent,
  },
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
