import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UserService } from 'src/app/services/user/user.service';
import { UserType } from 'src/app/services/user/user.types';

@Component({
  selector: 'app-user-details-dialog',
  templateUrl: './user-details-dialog.component.html',
  styleUrls: ['./user-details-dialog.component.scss'],
})
export class UserDetailsDialogComponent implements OnInit {
  userDetails: UserType = {
    nome: '',
    cpf: '',
    cidade: '',
    dataDeNascimento: '',
    estadoCivil: '',
    id: '',
    profissao: '',
    uf: '',
  };

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { userId: string },
    private userService: UserService
  ) { }

  ngOnInit() {
    this.userService.getUser(this.data.userId).subscribe((data) => {
      this.userDetails = data;
    });
  }
}
