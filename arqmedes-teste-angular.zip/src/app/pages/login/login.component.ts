import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth/auth.service';
import { HttpService } from 'src/app/services/http/http.service';
import { SnackbarService } from 'src/app/services/snackbar/snackbar.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  form = this.formBuilder.group({
    email: ['', [Validators.email, Validators.required]],
    password: ['', [Validators.maxLength(8), Validators.required]],
  });

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private httpService: HttpService,
    private snackbarService: SnackbarService,
    private authService: AuthService
  ) { }

  getError(path: string, errorCode: string) {
    return this.form.getError(errorCode, path);
  }

  handleForm() {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }

    const { email, password } = this.form.getRawValue();

    this.httpService
      .post('/login', {
        email,
        password,
      })
      .subscribe({
        next: () => {
          this.authService.isAuthenticated = true;
          this.router.navigateByUrl('/dashboard/users');
        },
        error: (err) => {
          this.snackbarService.openDefault(
            err?.error?.message || 'Falha no login'
          );
        },
      });

    // console.debug('valid form submitted');
  }
}
