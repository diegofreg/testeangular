import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';

import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { ConfirmationDialogComponent } from 'src/app/dialogs/confirmation-dialog/confirmation-dialog.component';
import { SnackbarService } from 'src/app/services/snackbar/snackbar.service';
import { UserService } from 'src/app/services/user/user.service';
import { brazilianNamePattern } from 'src/app/utils/regexp';

@Component({
  selector: 'app-user-page',
  templateUrl: './user-page.component.html',
  styleUrls: ['./user-page.component.scss'],
})
export class UserPageComponent implements OnInit {
  ESTADOS_CIVIS = ['Solteiro(a)', 'Casado(a)', 'Viúvo(a)'];

  PROFISSOES = [
    'Professor(a) de História',
    'Desenvolvedor(a) backend',
    'Arquiteto(a)',
    'Atleta',
    'Jogador(a) de Futebol',
    'Engenheiro(a)',
    'Doutor(a)',
    'Cientista',
  ];

  CIDADES: { [k: string]: string[] } = {
    PI: ['Teresina'],
    SP: ['São Paulo', 'Espírito Santo do Pinhal', 'Campinas'],
    RJ: ['Rio de Janeiro', 'Angra dos Reis', 'Niterói', 'Bom Jardim'],
  };

  UFS = ['PI', 'SP', 'RJ'];

  cidades = new BehaviorSubject<string[]>([]);

  form = this.formBuilder.nonNullable.group({
    nome: ['', [Validators.required, Validators.pattern(brazilianNamePattern)]],
    profissao: ['', [Validators.required]],
    estadoCivil: ['', [Validators.required]],
    uf: ['', [Validators.required]],
    cidade: ['', [Validators.required]],
    dataDeNascimento: ['' as string | Date, [Validators.required]],
    cpf: ['', [Validators.required]],
    id: [''],
  });

  pageTitle = '';

  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    private route: ActivatedRoute,
    private router: Router,
    private snackbarService: SnackbarService,
    private dialog: MatDialog
  ) { }

  ngOnInit() {
    this.route.params.subscribe((params) => {
      if (params['id']) {
        this.pageTitle = 'Editar Usuário';

        this.userService.getUser(params['id']).subscribe((user) => {
          this.form.reset({
            cidade: user.cidade,
            cpf: user.cpf,
            dataDeNascimento: new Date(user.dataDeNascimento),
            estadoCivil: user.estadoCivil,
            nome: user.nome,
            profissao: user.profissao,
            uf: user.uf,
            id: params['id'],
          });
        });

        this.form.controls.cpf.disable();
      } else {
        this.pageTitle = 'Adicionar Usuário';
      }
    });

    this.form.controls.uf.valueChanges.subscribe((uf) => {
      this.form.controls.cidade.reset();
      if (uf) {
        this.form.controls.cidade.enable();
        this.cidades.next(this.CIDADES[uf]);
      } else {
        this.form.controls.cidade.disable();
        this.cidades.next([]);
      }
    });
  }

  formResponseHandler() {
    return {
      next: () => {
        this.snackbarService.openDefault('Dados salvos');

        this.router.navigate(['/dashboard/users']);
      },
      error: (err: HttpErrorResponse) => {
        this.snackbarService.openDefault(
          err?.error?.message || 'Algo deu errado. Tente novamente'
        );
      },
    };
  }

  onFormSubmit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const {
      cidade,
      nome,
      uf,
      dataDeNascimento: dataNascimento,
      estadoCivil,
      profissao,
      cpf,
      id,
    } = this.form.getRawValue();

    const dataDeNascimento =
      typeof dataNascimento === 'string'
        ? dataNascimento
        : dataNascimento.toISOString();

    if (id) {
      // new user
      this.userService
        .updateUser(id, {
          cidade,
          profissao,
          estadoCivil,
          dataDeNascimento,
          uf,
          nome,
        })
        .subscribe(this.formResponseHandler());
    } else {
      // update user
      this.userService
        .addUser({
          cidade,
          profissao,
          estadoCivil,
          dataDeNascimento,
          uf,
          cpf,
          nome,
        })
        .subscribe(this.formResponseHandler());
    }
  }

  goBack() {
    this.router.navigateByUrl('/dashboard/users');
  }

  cancelForm() {
    if (!this.form.touched) {
      this.router.navigateByUrl('/dashboard/users');
      return;
    }

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        message: `Há dados não salvos. Deseja descartá-los?`,
      },
      panelClass: 'confirmation-dialog-panel',
    });

    dialogRef.afterClosed().subscribe((ans) => {
      if (!ans) return;

      this.goBack();
    });
  }
}
