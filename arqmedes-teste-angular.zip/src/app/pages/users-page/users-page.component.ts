import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { debounceTime } from 'rxjs';
import { ConfirmationDialogComponent } from 'src/app/dialogs/confirmation-dialog/confirmation-dialog.component';
import { UserDetailsDialogComponent } from 'src/app/dialogs/user-details-dialog/user-details-dialog.component';
import { SnackbarService } from 'src/app/services/snackbar/snackbar.service';
import { UserService } from 'src/app/services/user/user.service';
import { UserType } from 'src/app/services/user/user.types';
import { brazilianNamePattern } from 'src/app/utils/regexp';

@Component({
  selector: 'app-users-page',
  templateUrl: './users-page.component.html',
  styleUrls: ['./users-page.component.scss'],
})
export class UsersPageComponent implements AfterViewInit, OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  searchControl = this.formBuilder.nonNullable.control('', [
    Validators.pattern(brazilianNamePattern),
    Validators.minLength(3),
  ]);

  tableColumns = ['actions', 'nome', 'dataDeNascimento', 'cpf', 'cidade'];

  dataSource = new MatTableDataSource<UserType>([]);

  lastSearchValue = '';

  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    private dialog: MatDialog,
    private snackbarService: SnackbarService
  ) { }

  ngOnInit() {
    this.loadUsers();

    this.searchControl.markAsTouched();

    this.searchControl.valueChanges
      .pipe(debounceTime(1000))
      .subscribe((value) => {
        const isInvalid = this.searchControl.invalid;
        const isSameAsPrevious = value === this.lastSearchValue;

        if (isInvalid || isSameAsPrevious) return;

        this.lastSearchValue = value;
        this.loadUsers();
      });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  loadUsers() {
    this.userService.getUsers(this.searchControl.value).subscribe((data) => {
      this.dataSource.data = data;
    });
  }

  viewUser(id: UserType['id']) {
    this.dialog.open<UserDetailsDialogComponent>(UserDetailsDialogComponent, {
      data: { userId: id },
    });
  }

  deleteUser(user: UserType) {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Excluir usuário',
        message: `Deseja realmente excluir ${user.nome} (CPF ${user.cpf})?`,
        confirmText: 'Excluir',
        confirmIcon: 'delete',
      },
      panelClass: 'confirmation-dialog-panel',
    });

    dialogRef.afterClosed;
    dialogRef.afterClosed().subscribe((ans) => {
      if (!ans) return;

      this.userService.deleteUser(user.id).subscribe({
        next: () => {
          this.snackbarService.openDefault('Usuário excluído');
          this.loadUsers();
        },
        error: (err) => {
          this.snackbarService.openDefault(
            err?.error?.message || 'Algo deu errado.'
          );
        },
      });
    });
  }
}
