import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root',
})
export class SnackbarService {
  constructor(private snackBar: MatSnackBar) { }

  openDefault(message: string, options?: MatSnackBarConfig) {
    this.snackBar.open(message, 'OK', { duration: 3000, ...options });
  }
}
