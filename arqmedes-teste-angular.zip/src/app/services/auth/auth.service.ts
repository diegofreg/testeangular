import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor() { }

  get isAuthenticated() {
    console.log(window.sessionStorage.getItem('loggedIn'));
    return window.sessionStorage.getItem('loggedIn') === 'true';
  }

  set isAuthenticated(newValue: boolean) {
    window.sessionStorage.setItem('loggedIn', String(newValue));
  }
}
