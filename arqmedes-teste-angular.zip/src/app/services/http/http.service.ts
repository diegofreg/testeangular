import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class HttpService {
  private urlPrefix = 'http://localhost:3000';

  constructor(private http: HttpClient) { }

  get<T>(path: string): Observable<T> {
    return this.http.get<T>(this.urlPrefix + path);
  }

  delete<T>(path: string): Observable<T> {
    return this.http.delete<T>(this.urlPrefix + path);
  }

  post<T>(path: string, data: any): Observable<T> {
    return this.http.post<T>(this.urlPrefix + path, data);
  }

  patch<T>(path: string, data: any): Observable<T> {
    return this.http.patch<T>(this.urlPrefix + path, data);
  }

  put<T>(path: string, data: any): Observable<T> {
    return this.http.put<T>(this.urlPrefix + path, data);
  }
}
