export type UserType = {
  nome: string;
  cpf: string;
  profissao: string;
  dataDeNascimento: string;
  estadoCivil: string;
  uf: string;
  cidade: string;
  id: string;
};

export type UserUpdateBody = {
  nome: string;
  profissao: string;
  dataDeNascimento: string;
  estadoCivil: string;
  uf: string;
  cidade: string;
};

export type UserCreateBody = UserUpdateBody & {
  cpf: string;
};
