import { Injectable } from '@angular/core';
import { HttpService } from '../http/http.service';
import { UserCreateBody, UserType, UserUpdateBody } from './user.types';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private httpService: HttpService) { }

  getUsers(searchTerm?: string) {
    let path = '/users';

    if (searchTerm) {
      path += `?nome_like=${searchTerm}`;
    }

    return this.httpService.get<UserType[]>(path);
  }

  getUser(id: UserType['id']) {
    return this.httpService.get<UserType>(`/users/${id}`);
  }

  updateUser(id: UserType['id'], body: UserUpdateBody) {
    return this.httpService.patch(`/users/${id}`, body);
  }

  addUser(body: UserCreateBody) {
    return this.httpService.post(`/users`, body);
  }

  deleteUser(id: UserType['id']) {
    return this.httpService.delete(`/users/${id}`);
  }
}
