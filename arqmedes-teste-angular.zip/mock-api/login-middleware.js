// code from
// https://lightrun.com/answers/typicode-json-server-how-to-mock-a-api-for-login

module.exports = (req, res, next) => {
  if (req.method == "POST" && req.path == "/login") {
    if (
      req.body.email === "diegofreg@gmail.com" &&
      req.body.password === "diego"
    ) {
      res.status(200).json({});
    } else {
      res.status(400).json({ message: "Email ou senha inválidos" });
    }
  } else {
    next();
  }
};
